
package randompasswordgenerator;
import java.security.SecureRandom;

public class RandomPasswordGenerator {
    private static final String LOWERCASE_CHARS = "abcdefghijklmnopqrstuvwxyz";
    private static final String UPPERCASE_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String DIGITS = "0123456789";
    private static final String SPECIAL_CHARS = "!@#$%^&*()_+";

    public static void main(String[] args) {
        int passwordLength = 12; // Specify the desired password length

        String generatedPassword = generatePassword(passwordLength);
        System.out.println("Generated password: " + generatedPassword);
    }

    // Static method to generate a random password
    public static String generatePassword(int length) {
        StringBuilder password = new StringBuilder();
        SecureRandom random = new SecureRandom();

        // Include at least one character from each category
        password.append(getRandomChar(LOWERCASE_CHARS, random));
        password.append(getRandomChar(UPPERCASE_CHARS, random));
        password.append(getRandomChar(DIGITS, random));
        password.append(getRandomChar(SPECIAL_CHARS, random));

        // Fill the remaining characters
        for (int i = 4; i < length; i++) {
            String allChars = LOWERCASE_CHARS + UPPERCASE_CHARS + DIGITS + SPECIAL_CHARS;
            password.append(getRandomChar(allChars, random));
        }

        return password.toString();
    }

    // Helper method to get a random character from a given set of characters
    private static char getRandomChar(String charSet, SecureRandom random) {
        int randomIndex = random.nextInt(charSet.length());
        return charSet.charAt(randomIndex);
    }
}




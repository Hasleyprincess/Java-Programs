
package atmprogramq3;

import java.util.Scanner;

// ATM class to represent the ATM functionality
class ATM {
    private static final String ATM_LOCATION = "Mubuga, Rwanda"; // Static variable for ATM location
    private static final int MAX_WITHDRAWAL_LIMIT = 1000; // Static variable for maximum withdrawal limit

    // Instance variables
    private double accountBalance;

    // Constructor to initialize account balance
    public ATM(double initialBalance) {
        this.accountBalance = initialBalance;
    }

    // Method for withdrawing money
    public void withdraw(double amount) {
        if (amount > 0 && amount <= MAX_WITHDRAWAL_LIMIT && amount <= accountBalance) {
            accountBalance -= amount;
            System.out.println("Withdrawal successful. Remaining balance: $" + accountBalance);
        } else {
            System.out.println("Invalid withdrawal amount or insufficient balance.");
        }
    }

    // Method for depositing money
    public void deposit(double amount) {
        if (amount > 0) {
            accountBalance += amount;
            System.out.println("Deposit successful. Updated balance: $" + accountBalance);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    // Method to check account balance
    public void checkBalance() {
        System.out.println("Current balance: $" + accountBalance);
    }

public class AtmProgramQ3 {

   
    public static void main(String[] args) {
      
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the ATM at " + ATM_LOCATION);
        System.out.print("Enter initial account balance: $");
        double initialBalance = scanner.nextDouble();

        ATM atm = new ATM(initialBalance);

        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Withdraw");
            System.out.println("2. Deposit");
            System.out.println("3. Check Balance");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter withdrawal amount: $");
                    double withdrawalAmount = scanner.nextDouble();
                    atm.withdraw(withdrawalAmount);
                    break;
                case 2:
                    System.out.print("Enter deposit amount: $");
                    double depositAmount = scanner.nextDouble();
                    atm.deposit(depositAmount);
                    break;
                case 3:
                    atm.checkBalance();
                    break;
                case 4:
                    System.out.println("Thank you for using our ATM!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }

    }
    
}

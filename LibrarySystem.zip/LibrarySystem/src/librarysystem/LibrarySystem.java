
package librarysystem;

import java.util.Scanner;

class Book {
    private String title;
    private String author;
    private boolean borrowed;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.borrowed = false; // Initialize as not borrowed
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public boolean isBorrowed() {
        return borrowed;
    }

    public void borrow() {
        borrowed = true;
    }

    public void returnBook() {
        borrowed = false;
    }
}

class Patron {
    private String name;
    private int borrowedBooksCount;
    private static final int MAX_BORROWED_BOOKS = 3; // Maximum books a patron can borrow

    public Patron(String name) {
        this.name = name;
        this.borrowedBooksCount = 0;
    }

    public String getName() {
        return name;
    }

    public boolean canBorrowMoreBooks() {
        return borrowedBooksCount < MAX_BORROWED_BOOKS;
    }

    public void borrowBook() {
        if (canBorrowMoreBooks()) {
            borrowedBooksCount++;
        } else {
            System.out.println("Maximum borrowing limit reached for " + name);
        }
    }

    public void returnBook() {
        if (borrowedBooksCount > 0) {
            borrowedBooksCount--;
        }
    }
}

public class LibrarySystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create a sample book and patron
        Book book = new Book("Great Expectations", "Charles Dickens");
        Patron patron = new Patron("Alice");

        // Demonstrate borrowing and returning a book
        patron.borrowBook();
        System.out.println(patron.getName() + " borrowed: " + book.getTitle());

        patron.returnBook();
        System.out.println(patron.getName() + " returned: " + book.getTitle());
    }
}


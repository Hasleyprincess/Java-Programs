
package sumbetweennumbers;

import java.util.Scanner;

public class SumBetweenNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first number: ");
        int firstNumber = scanner.nextInt();

        System.out.print("Enter the second number: ");
        int secondNumber = scanner.nextInt();

        int sum = calculateSum(firstNumber, secondNumber);

        System.out.println("Sum of numbers between " + firstNumber + " and " + secondNumber + " is: " + sum);
    }

    // Static method to calculate the sum between two numbers
    public static int calculateSum(int start, int end) {
        int sum = 0;
        for (int i = start; i <= end; i++) {
            sum += i;
        }
        return sum;
    }
}



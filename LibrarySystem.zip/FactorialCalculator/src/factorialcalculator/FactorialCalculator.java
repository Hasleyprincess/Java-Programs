
package factorialcalculator;

public class FactorialCalculator {
    public static void main(String[] args) {
        int number = 5; // Example: Calculate factorial for 6

        long factorial = calculateFactorial(number);

        System.out.println("Factorial of " + number + " = " + factorial);
    }

    // Static recursive method to calculate factorial
    public static long calculateFactorial(int n) {
        if (n >= 1) {
            return n * calculateFactorial(n - 1);
        } else {
            return 1;
        }
    }
}


package simplecalculatorapp;


import java.util.Scanner;

class Calculator {
    // Constructor (initialize the calculator)
    public Calculator() {
        System.out.println("Simple Calculator Initialized!");
    }

    // Static method for addition
    public static double add(double num1, double num2) {
        return num1 + num2;
    }

    // Static method for subtraction
    public static double subtract(double num1, double num2) {
        return num1 - num2;
    }

    // Static method for multiplication
    public static double multiply(double num1, double num2) {
        return num1 * num2;
    }

    // Static method for division
    public static double divide(double num1, double num2) {
        if (num2 != 0) {
            return num1 / num2;
        } else {
            System.out.println("Error: Cannot divide by zero.");
            return Double.NaN; // Not-a-Number
        }
    }
}

public class SimpleCalculatorApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create a calculator object (initialize)
        Calculator calculator = new Calculator();

        System.out.print("Enter the first number: ");
        double num1 = scanner.nextDouble();
        
        System.out.print("Enter the operation (+, -, *, /): ");
        char operation = scanner.next().charAt(0);
        
        System.out.print("Enter the second number: ");
        double num2 = scanner.nextDouble();

       

        double result;
        switch (operation) {
            case '+':
                result = Calculator.add(num1, num2);
                break;
            case '-':
                result = Calculator.subtract(num1, num2);
                break;
            case '*':
                result = Calculator.multiply(num1, num2);
                break;
            case '/':
                result = Calculator.divide(num1, num2);
                break;
            default:
                System.out.println("Invalid operation.");
                return;
        }

        System.out.println("Result: " + result);
    }
}



package managestudentrecords;
import java.util.Scanner;

class Student {
    private int studentId;
    private String name;
    private double grade;

    public Student(int studentId, String name, double grade) {
        this.studentId = studentId;
        this.name = name;
        this.grade = grade;
    }
public class ManageStudentRecords {

         public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Student[] students = new Student[100]; // Maximum number of students

        // Add a student
        System.out.print("Enter Student ID: ");
        int id = input.nextInt();
        input.nextLine(); // Consume newline
        System.out.print("Enter Student Name: ");
        String studentName = input.nextLine();
        System.out.print("Enter Student Grade: ");
        double studentGrade = input.nextDouble();

        students[0] = new Student(id, studentName, studentGrade);
        System.out.println("Student added successfully!");

        // Display student information
        System.out.println("\nStudent Information:");
        System.out.println("Student ID: " + students[0].studentId);
        System.out.println("Name: " + students[0].name);
        System.out.println("Grade: " + students[0].grade);
    }
}
    }
    


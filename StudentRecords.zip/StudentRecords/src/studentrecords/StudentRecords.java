
package studentrecords;
import java.util.Scanner;

class Student {
    private int studentId;
    private String name;
    private double grade;

    // Static variables
    private static final int MAX_STUDENTS = 100; // Maximum number of students
    private static final double PASSING_GRADE = 60.0; // Passing grade

    // Constructor to initialize student details
    public Student(int studentId, String name, double grade) {
        this.studentId = studentId;
        this.name = name;
        this.grade = grade;
    }

    // Static method to add a student
    public static void addStudent(Student[] students, int index, int studentId, String name, double grade) {
        if (index < MAX_STUDENTS) {
            students[index] = new Student(studentId, name, grade);
            System.out.println("Student added successfully!");
        } else {
            System.out.println("Maximum number of students reached.");
        }
    }

    // Static method to update student grade
    public static void updateGrade(Student student, double newGrade) {
        student.grade = newGrade;
        System.out.println("Grade updated successfully!");
    }

    // Static method to display student information
    public static void displayStudent(Student student) {
        System.out.println("Student ID: " + student.studentId);
        System.out.println("Name: " + student.name);
        System.out.println("Grade: " + student.grade);
    }

public class StudentRecord {

    public static void main(String[] args) {
        
         Scanner input = new Scanner(System.in);
        Student[] students = new Student[MAX_STUDENTS];
        int studentCount = 0;

        while (true) {
            System.out.println("\nStudent Record Management System");
            System.out.println("1. Add Student");
            System.out.println("2. Update Grade");
            System.out.println("3. Display Student Information");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = input.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    int id = input.nextInt();
                    input.nextLine(); // Consume newline
                    System.out.print("Enter Student Name: ");
                    String studentName = input.nextLine();
                    System.out.print("Enter Student Grade: ");
                    double studentGrade = input.nextDouble();
                    addStudent(students, studentCount, id, studentName, studentGrade);
                    studentCount++;
                    break;
                case 2:
                    System.out.print("Enter Student ID to update grade: ");
                    int searchId = input.nextInt();
                    for (int i = 0; i < studentCount; i++) {
                        if (students[i].studentId == searchId) {
                            System.out.print("Enter new grade: ");
                            double newGrade = input.nextDouble();
                            updateGrade(students[i], newGrade);
                            break;
                        }
                    }
                    break;
                case 3:
                    System.out.print("Enter Student ID to display information: ");
                    int displayId = input.nextInt();
                    for (int i = 0; i < studentCount; i++) {
                        if (students[i].studentId == displayId) {
                            displayStudent(students[i]);
                            break;
                        }
                    }
                    break;
                case 4:
                    System.out.println("Exiting Student Record Management System. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
    }
    

                                
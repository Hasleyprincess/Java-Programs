
package rectangleprogramq1;

class Rectangle {
    // Instance variables for length and width
    private double length;
    private double width;

    // Constructor to initialize length and width
    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    // Method to calculate the area of the rectangle
    public double getArea() {
        return length * width;
    }

    // Method to calculate the perimeter of the rectangle
    public double getPerimeter() {
        return 2 * (length + width);
    }
public class RectangleProgramQ1 {

   
    public static void main(String[] args) {
       double length = 10.0; // Example length
        double width = 5.0;   // Example width

        // Create a rectangle object
        Rectangle myRectangle = new Rectangle(length, width);

        // Display area and perimeter
        System.out.println("Rectangle dimensions:");
        System.out.println("Length: " + length);
        System.out.println("Width: " + width);
        System.out.println("Area: " + myRectangle.getArea());
        System.out.println("Perimeter: " + myRectangle.getPerimeter());
    }
}
    }
    
}

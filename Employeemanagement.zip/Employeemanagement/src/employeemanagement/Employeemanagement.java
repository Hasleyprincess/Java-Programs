
package employeemanagement;

class Employee{
    int emp_id;
    String name;
    int Salary;
    static int max_number=100;
    static String companyName="UBWIZA ARTS";
    Employee(int id,String n,int s){
        emp_id=id;
        name=n;
        Salary=s;
    }
    static void adding(){
        
    }
    static void update(){
        
    }
    void displayEmployeeDetails(){
        System.out.println("Employee id"+emp_id);
        System.out.println("Employee id"+name);
        System.out.println("Employee id"+Salary);
    }
}
public class Employeemanagement {

   
    public static void main(String[] args) {
        
    }
    
}
 
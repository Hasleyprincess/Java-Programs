
package menupractice;
import java.awt.*;
import javax.accessibility.Accessible;
import javax.swing.*;
import java.awt.event.*;

/**
 *
 * @author user
 */
public class MenuPractice extends MenuItem implements Accessible,ActionListener{
    JFrame n;
    MenuBar mb;
    TextField t1,t2;
    Label l1,l2,title;
    Menu page,edit,help;
    MenuItem login,stud;
   Button b1;
   JPanel p1,p2,p3,p4,p5;
   public MenuPractice() {
       mb=new MenuBar();
       page=new Menu();
       edit=new Menu();
       help=new Menu();
       login=new MenuItem("Login");
       stud=new MenuItem("Student");
       n=new JFrame("my menus");
       
       page.add(login);
       page.add(stud);
       mb.add(page);
       mb.add(edit);
       mb.add(help);
       page.setLabel("Page");
       edit.setLabel("Edit");
       help.setLabel("Help");
       n.setMenuBar(mb);
      l1=new Label("Username");
       n.setBackground(Color.yellow);
        n.setSize(610,500);
      n.setLayout(new FlowLayout());
      n.setVisible(true);
      
      p1=new JPanel();
               p1.setBackground(Color.blue);
               
               p2=new JPanel();
               p2.setBackground(Color.MAGENTA);
               p3=new JPanel();
               p3.setBackground(Color.green);
               
               p4=new JPanel();
               p4.setBackground(Color.cyan);
              
               p5=new JPanel();
               p5.setBackground(Color.green);
               n.setLayout(null);
               p1.setBounds(0, 0, 600, 80);
               p2.setBounds(0, 375, 600, 80);
               p3.setBounds(0, 80, 120, 300);
               p4.setBounds(120, 80, 350, 300);
               p5.setBounds(470, 80, 120, 300);
               
               n.add(p1);
               n.add(p2);
               n.add(p3);
               n.add(p4);
               n.add(p5);
               
      login.addActionListener(this);
      stud.addActionListener(this);
    
    }
   
    public static void main(String[] args) {
        MenuPractice a=new MenuPractice();
    }

    /**
     *
     * @param l
     */
    @Override
    public void actionPerformed(ActionEvent l) {
        
           if(l.getSource()==login){
               title=new Label("Simple Login Form");
               p1.add(title);
               p1.getAccessibleContext();
               l1=new Label("Username");
               l2=new Label("Password");
               t1=new TextField();
               t2=new TextField();
               b1=new Button("Login");
               p4.setLayout(null);
               p4.add(l1);
               p4.add(l2);
               p4.add(t1);
               p4.add(t2);
               p4.add(b1);
               
               l1.setBounds(40, 50, 80, 40);
               l2.setBounds(40, 120, 80, 40);
               t1.setBounds(90, 50, 180, 30);
               t2.setBounds(90, 120, 180, 30);
               b1.setBounds(130, 190, 90, 40);
               
               
        }
           else if(l.getSource()==stud){
               title=new Label("STUDENT PANEL");
               p1.add(title);
   
    }
           else{
               System.exit(0);
        
           }

    }

  
             }

    


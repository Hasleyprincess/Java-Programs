
package pallindrome;
import java.util.Scanner;

public class Pallindrome {
  
    public static void main(String[] args) {
      System.out.println("Input a word to check whether it is pallindrome\n");
      String s; 
      
      
     Scanner str= new Scanner(System.in);
     s=str.nextLine();
     String reverse=new StringBuffer(s).reverse().toString();
     
     if(s.equals(reverse)){
         System.out.println("YES");
     }
     else{
         System.out.println("NO");
     }
    }
}
    
